# WULF 5분 투자 대시보드

휴대폰/PC에서 주소로 접속할 수 있도록 GitHub Pages에 배포하는 정적 웹사이트입니다.

## 가장 쉬운 배포 방법

1. GitHub에 로그인합니다.
2. New repository를 누릅니다.
3. Repository 이름을 `wulf-investment-dashboard`로 입력합니다.
4. 가능하면 Public으로 생성합니다. (GitHub Free에서 Pages를 쓰기 가장 간단합니다.)
5. 이 폴더의 파일 전체를 repository에 업로드합니다.
6. Settings → Pages로 이동합니다.
7. Build and deployment의 Source를 `GitHub Actions`로 선택합니다.
8. Actions가 완료되면 Pages 화면의 `Visit site`에서 공개 주소를 확인합니다.

주소는 대략 다음 형태입니다.
`https://사용자이름.github.io/wulf-investment-dashboard/`

## 주의

- 현재 체크리스트/메모는 브라우저의 localStorage에 저장됩니다.
- 따라서 PC에서 입력한 개인 메모가 휴대폰으로 자동 동기화되지는 않습니다.
- 사이트 자체는 누구나 주소로 볼 수 있습니다.
- 개인 메모까지 여러 기기에서 동기화하려면 다음 단계에서 Supabase/Firebase 같은 데이터베이스와 로그인 기능을 붙이면 됩니다.
- 공개 사이트에는 비밀번호, 계좌번호 등 민감한 정보를 입력하지 마세요.
